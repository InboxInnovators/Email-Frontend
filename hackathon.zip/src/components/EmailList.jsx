import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import graphService from '../services/graphService';
import authService from '../services/authService';

const EmailList = () => {
  const [emails, setEmails] = useState([]);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchEmails = async () => {
      try {
        const fetchedEmails = await graphService.getEmails();
        setEmails(fetchedEmails);
        setLoading(false);
      } catch (error) {
        console.error("Failed to fetch emails:", error);
        setLoading(false);
      }
    };

    fetchEmails();
  }, []);

  const handleLogout = () => {
    authService.logout();
    navigate('/login');
  };

  if (loading) {
    return <div>Loading emails...</div>;
  }

  return (
    <div>
      <h1>Your Emails</h1>
      <button onClick={handleLogout}>Logout</button>
      {emails.map((email) => (
        <div key={email.id}>
          <h3>{email.subject}</h3>
          <p>{email.bodyPreview}</p>
        </div>
      ))}
    </div>
  );
};

export default EmailList; 