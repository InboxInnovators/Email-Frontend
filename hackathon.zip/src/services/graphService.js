import { Client } from "@microsoft/microsoft-graph-client";
import authService from "./authService";

class GraphService {
  constructor() {
    this.client = null;
  }

  async getClient() {
    if (!this.client) {
      const token = await authService.login();
      
      this.client = Client.init({
        authProvider: (done) => {
          done(null, token);
        }
      });
    }
    return this.client;
  }

  async getEmails() {
    try {
      const client = await this.getClient();
      const messages = await client
        .api('/me/messages')
        .select(['subject', 'bodyPreview', 'sender', 'receivedDateTime'])
        .top(10)
        .orderby('receivedDateTime DESC')
        .get();

      return messages.value;
    } catch (error) {
      console.error("Error fetching emails:", error);
      throw error;
    }
  }

  async getUserProfile() {
    try {
      const client = await this.getClient();
      const user = await client.api('/me').get();
      return user;
    } catch (error) {
      console.error("Error fetching user profile:", error);
      throw error;
    }
  }
}

export default new GraphService(); 