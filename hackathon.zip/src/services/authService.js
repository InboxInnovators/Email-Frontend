import * as msal from "@azure/msal-browser";

const msalConfig = {
  auth: {
    clientId: "YOUR_CLIENT_ID",
    authority: `https://login.microsoftonline.com/YOUR_TENANT_ID`,
    redirectUri: window.location.origin
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: false
  }
};

const loginRequest = {
  scopes: ["openid", "profile", "email", "User.Read"]
};

class AuthService {
  constructor() {
    this.msalInstance = new msal.PublicClientApplication(msalConfig);
  }

  async login() {
    try {
      // Attempt silent login first
      const accounts = this.msalInstance.getAllAccounts();
      
      if (accounts.length > 0) {
        const silentRequest = {
          account: accounts[0],
          scopes: loginRequest.scopes
        };

        const response = await this.msalInstance.acquireTokenSilent(silentRequest);
        return response.accessToken;
      }

      // If no existing account, initiate login
      const response = await this.msalInstance.loginPopup(loginRequest);
      
      // Acquire token after successful login
      const tokenResponse = await this.msalInstance.acquireTokenSilent({
        account: response.account,
        scopes: loginRequest.scopes
      });

      return tokenResponse.accessToken;
    } catch (error) {
      console.error("Authentication error:", error);
      
      // If silent login fails, use popup
      if (error instanceof msal.InteractionRequiredAuthError) {
        const response = await this.msalInstance.loginPopup(loginRequest);
        const tokenResponse = await this.msalInstance.acquireTokenSilent({
          account: response.account,
          scopes: loginRequest.scopes
        });
        return tokenResponse.accessToken;
      }
      
      throw error;
    }
  }

  async logout() {
    const accounts = this.msalInstance.getAllAccounts();
    
    if (accounts.length > 0) {
      this.msalInstance.logoutPopup({
        account: accounts[0]
      });
    }
  }

  isAuthenticated() {
    const accounts = this.msalInstance.getAllAccounts();
    return accounts.length > 0;
  }
}

export default new AuthService(); 